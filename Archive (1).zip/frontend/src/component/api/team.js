const Users = [
[
      {
        "Round1": [
          {
            "Team1": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team2": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team3": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team4": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ]
          }
        ],
        "Round2": [
          {
            "Team1": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team2": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team3": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team4": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ]
          }
        ],
        "Round3": [
          {
            "Team1": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team2": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team3": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team4": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ]
          }
        ],
        "Round4": [
          {
            "Team1": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team2": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team3": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ],
            "Team4": [
              {
                "TeamMem1": "Member 1",
                "TeamMem2": "Member 2",
                "TeamMem3": "Member 3",
                "TeamMem4": "Member 4"
              }
            ]
          }
        ]
      }
    ]
]

export default Users;