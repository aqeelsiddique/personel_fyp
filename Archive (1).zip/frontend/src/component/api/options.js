const options = [
    {
        label: "Round 1",
        value: "Round 1",
    },
    {
        label: "Round 2",
        value: "Round 2",
    },
    {
        label: "Round 3",
        value: "Round 3",
    },
    {
        label: "Round 4",
        value: "Round 4",
    },
    {
        label: "Final Round",
        value: "Final Round",
    },
];

export default options