const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://fyp:fypapp@cluster0.d4xtkxl.mongodb.net/user?retryWrites=true&w=majority");
