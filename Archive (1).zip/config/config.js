
PORT = 4003

SECRET_KEY = "mynameisaqeelwebdeveloper"